package org.cap.exception;

public class InvalidInitialAmountException extends Exception {

	public InvalidInitialAmountException(String msg){
		super(msg);
	}
}
