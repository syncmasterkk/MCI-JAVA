package org.cap.test.bankapp;

public interface GoodTestCategory {

}
