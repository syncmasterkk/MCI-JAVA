package org.cap.order.integration;

public class WMSUnavailableException extends Exception {

	private static final long serialVersionUID = -6118793265317370209L;

	public WMSUnavailableException(String message) {
		super(message);
	}
}